package edu.eci.arsw.threads;

import edu.eci.arsw.blacklistvalidator.HostBlackListsValidator;
import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;

import java.util.LinkedList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Busqueda extends Thread{

    private String ipaddress;
    private HostBlacklistsDataSourceFacade skds=HostBlacklistsDataSourceFacade.getInstance();
    private int lastip;
    private int firstip;
    ConcurrentLinkedQueue<Integer> blackListOcurrences=new ConcurrentLinkedQueue<>();
    private static AtomicInteger ocurrencesCount = new AtomicInteger(0);
    private AtomicInteger checkedListsCount= new AtomicInteger(0);


    public Busqueda(String ipaddress, int firstip, int lastip){
        this.ipaddress=ipaddress;
        this.lastip=lastip;
        this.firstip=firstip;
    }
    public void run(){
        for(int i = firstip;i<lastip && ocurrencesCount.get()< HostBlackListsValidator.BLACK_LIST_ALARM_COUNT;i++){
            checkedListsCount.getAndIncrement();
            if (skds.isInBlackListServer(i, ipaddress)) {
                blackListOcurrences.add(i);
                ocurrencesCount.getAndIncrement();
            }
        }
//        if (ocurrencesCount>=HostBlackListsValidator.BLACK_LIST_ALARM_COUNT){
//            skds.reportAsNotTrustworthy(ipaddress);
//        }
//        else{
//            skds.reportAsTrustworthy(ipaddress);
//        }
    }

    public ConcurrentLinkedQueue<Integer> getBlackListOcurrences() {
        return blackListOcurrences;
    }

    public static AtomicInteger getOcurrencesCount() {
        return ocurrencesCount;
    }

    public AtomicInteger getCheckedListsCount() {
        return checkedListsCount;
    }
}
